I appreciate that you chose my challenge! Don’t be afraid, it’s not that hard! :)

Some useful stuff before you crack it up:
1) I suggest you using Windows for this challenge. The program size is 148 KB.
2) In the Debug folder, you will find two installers, choose whichever you like.
3) The installer will create a desktop shortcut on your Desktop. Double click and the game is open now.
4) If you finish with the game, you can easily delete it by finding it in the Add or remove programs or just using an uninstaller for example iObit.
5) If you have ANY problems even if it is small or critical, please contact with Csia Kitti/Kitkat in the Wargame Support Team.

Have fun! :)
